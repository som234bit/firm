document.getElementById("learnMoreBtn").addEventListener("click", function(event) {

    event.preventDefault();

    alert("Thank you for clicking the Learn More button!");

});